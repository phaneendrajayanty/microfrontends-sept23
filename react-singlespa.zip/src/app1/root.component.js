import React from 'react';

export default class Root extends React.Component {
  render() {
    return (
      <div>
      <div style={{marginTop: '100px'}}>
        This was rendered by app 1, which is written in React.
        Include 
      </div>
      <h1> Include what ever code base you required based on business requirement</h1>
      </div>
    );
  }
}
