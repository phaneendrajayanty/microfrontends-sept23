import {Component} from '@angular/core';

@Component({
  template: `
    <div>
      Subroute 1 is workingg!
    </div>
  `,
})
export class Subroute1 {
}
